import tkinter as tk
from tkinter import ttk, messagebox
import pymysql
from tkinter.filedialog import asksaveasfilename
import pandas as pd
import matplotlib
matplotlib.use('TkAgg')  # Usar TkAgg para generar gráficos en ventanas emergentes
import matplotlib.pyplot as plt


class Database:
    def __init__(self, host="localhost", user="root", password="curso", database="ENCUESTAS"):
        try:
            self.connection = pymysql.connect(
                host=host,
                user=user,
                password=password,
                database=database,
                cursorclass=pymysql.cursors.DictCursor
            )
            self.cursor = self.connection.cursor()
        except pymysql.MySQLError as err:
            messagebox.showerror("Error de conexión", f"No se pudo conectar a la base de datos: {err}")

    def execute_query(self, query, params=None):
        try:
            self.cursor.execute(query, params or ())
            self.connection.commit()
        except pymysql.MySQLError as err:
            messagebox.showerror("Error de consulta", f"Error al ejecutar la consulta: {err}")

    def fetch_all(self, query, params=None):
        try:
            self.cursor.execute(query, params or ())
            return self.cursor.fetchall()
        except pymysql.MySQLError as err:
            messagebox.showerror("Error de consulta", f"Error al ejecutar la consulta: {err}")
            return []

    def close(self):
        self.cursor.close()
        self.connection.close()


def export_to_excel(data, columns):
    file_path = asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel Files", "*.xlsx")])
    if file_path:
        df = pd.DataFrame(data, columns=columns)
        df.to_excel(file_path, index=False)
        messagebox.showinfo("Exportación exitosa", f"Archivo guardado en {file_path}")


def plot_data(data, title):
    labels, values = zip(*data)
    plt.figure(figsize=(10, 6))
    plt.bar(labels, values, color='skyblue')
    plt.title(title)
    plt.xlabel("Categoría")
    plt.ylabel("Cantidad")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()  # Abre el gráfico en una ventana emergente


class App:
    def __init__(self):
        self.db = Database()
        self.root = tk.Tk()
        self.root.title("Gestión de Encuestas")
        self.root.geometry("900x700")
        self.root.configure(bg="#f5f5f5")

        # Estilos
        style = ttk.Style()
        style.configure("TLabel", font=("Arial", 12), background="#f5f5f5")
        style.configure("TButton", font=("Arial", 12), background="#0078d7", foreground="black", padding=5)
        style.map("TButton", background=[("active", "#005a9e")])
        style.configure("Treeview", font=("Arial", 10), rowheight=25)
        style.configure("Treeview.Heading", font=("Arial", 12, "bold"))

        self.id_var = tk.IntVar()
        self.edad_var = tk.IntVar()
        self.sexo_var = tk.StringVar()
        self.bebidas_semana_var = tk.IntVar()
        self.cervezas_semana_var = tk.IntVar()
        self.bebidas_fin_semana_var = tk.IntVar()
        self.bebidas_destiladas_semana_var = tk.IntVar()
        self.vinos_semana_var = tk.IntVar()
        self.perdidas_control_var = tk.IntVar()
        self.diversion_dependencia_var = tk.StringVar()
        self.problemas_digestivos_var = tk.StringVar()
        self.tension_alta_var = tk.StringVar()
        self.dolor_cabeza_var = tk.StringVar()

        self.setup_ui()

    def setup_ui(self):
        frame = ttk.Frame(self.root)
        frame.pack(padx=20, pady=20, fill=tk.X)

        labels = [
            "ID Encuesta:", "Edad:", "Sexo:", "Bebidas/semana:",
            "Cervezas/semana:", "Bebidas fin semana:", "Destiladas/semana:",
            "Vinos/semana:", "Pérdidas de control:", "Diversión/Dependencia:",
            "Problemas digestivos:", "Tensión alta:", "Dolor de cabeza:"
        ]

        variables = [
            self.id_var, self.edad_var, self.sexo_var, self.bebidas_semana_var,
            self.cervezas_semana_var, self.bebidas_fin_semana_var, self.bebidas_destiladas_semana_var,
            self.vinos_semana_var, self.perdidas_control_var, self.diversion_dependencia_var,
            self.problemas_digestivos_var, self.tension_alta_var, self.dolor_cabeza_var
        ]

        for i, (label_text, variable) in enumerate(zip(labels, variables)):
            ttk.Label(frame, text=label_text).grid(row=i, column=0, sticky="e", pady=5)
            ttk.Entry(frame, textvariable=variable, width=25).grid(row=i, column=1, pady=5)

        button_frame = ttk.Frame(self.root)
        button_frame.pack(pady=10, fill=tk.X)

        buttons = [
            ("Crear", self.create_record),
            ("Leer", self.read_records),
            ("Actualizar", self.update_record),
            ("Eliminar", self.delete_record),
            ("Exportar", self.export_data),
            ("Gráficos", self.show_charts)
        ]

        for text, command in buttons:
            ttk.Button(button_frame, text=text, command=command).pack(side=tk.LEFT, padx=5)

        tree_frame = ttk.Frame(self.root)
        tree_frame.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        self.tree = ttk.Treeview(tree_frame, columns=(
            "ID", "Edad", "Sexo", "BebidasSemana", "CervezasSemana",
            "BebidasFinSemana", "BebidasDestiladasSemana", "VinosSemana",
            "PerdidasControl", "DiversionDependenciaAlcohol",
            "ProblemasDigestivos", "TensionAlta", "DolorCabeza"
        ), show="headings")

        for col in self.tree["columns"]:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100, anchor="center")

        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def create_record(self):
        try:
            record = (
                self.id_var.get(), self.edad_var.get(), self.sexo_var.get(), self.bebidas_semana_var.get(),
                self.cervezas_semana_var.get(), self.bebidas_fin_semana_var.get(), self.bebidas_destiladas_semana_var.get(),
                self.vinos_semana_var.get(), self.perdidas_control_var.get(), self.diversion_dependencia_var.get(),
                self.problemas_digestivos_var.get(), self.tension_alta_var.get(), self.dolor_cabeza_var.get()
            )
            if all(record):
                query = """
                    INSERT INTO ENCUESTA (
                        idEncuesta, edad, Sexo, BebidasSemana, CervezasSemana,
                        BebidasFinSemana, BebidasDestiladasSemana, VinosSemana,
                        PerdidasControl, DiversionDependenciaAlcohol,
                        ProblemasDigestivos, TensionAlta, DolorCabeza
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                self.db.execute_query(query, record)
                messagebox.showinfo("Éxito", "Registro creado exitosamente.")
                self.read_records()
            else:
                messagebox.showwarning("Campos vacíos", "Por favor, completa todos los campos.")
        except ValueError:
            messagebox.showwarning("Datos inválidos", "Por favor, verifica que los campos numéricos sean correctos.")

    def read_records(self):
        query = "SELECT * FROM ENCUESTA"
        records = self.db.fetch_all(query)
        for row in self.tree.get_children():
            self.tree.delete(row)
        for record in records:
            self.tree.insert("", tk.END, values=tuple(record.values()))

    def update_record(self):
        selected = self.tree.focus()
        if selected:
            values = self.tree.item(selected, "values")
            try:
                updated_record = (
                    self.edad_var.get(), self.sexo_var.get(), self.bebidas_semana_var.get(),
                    self.cervezas_semana_var.get(), self.bebidas_fin_semana_var.get(),
                    self.bebidas_destiladas_semana_var.get(), self.vinos_semana_var.get(),
                    self.perdidas_control_var.get(), self.diversion_dependencia_var.get(),
                    self.problemas_digestivos_var.get(), self.tension_alta_var.get(),
                    self.dolor_cabeza_var.get(), values[0]
                )
                query = """
                    UPDATE ENCUESTA SET
                        edad = %s, Sexo = %s, BebidasSemana = %s, CervezasSemana = %s,
                        BebidasFinSemana = %s, BebidasDestiladasSemana = %s, VinosSemana = %s,
                        PerdidasControl = %s, DiversionDependenciaAlcohol = %s,
                        ProblemasDigestivos = %s, TensionAlta = %s, DolorCabeza = %s
                    WHERE idEncuesta = %s
                """
                self.db.execute_query(query, updated_record)
                messagebox.showinfo("Éxito", "Registro actualizado exitosamente.")
                self.read_records()
            except ValueError:
                messagebox.showwarning("Datos inválidos", "Por favor, verifica los campos.")
        else:
            messagebox.showwarning("Selección requerida", "Por favor, selecciona un registro.")

    def delete_record(self):
        selected = self.tree.focus()
        if selected:
            values = self.tree.item(selected, "values")
            query = "DELETE FROM ENCUESTA WHERE idEncuesta = %s"
            self.db.execute_query(query, (values[0],))
            messagebox.showinfo("Éxito", "Registro eliminado exitosamente.")
            self.read_records()
        else:
            messagebox.showwarning("Selección requerida", "Por favor, selecciona un registro.")

    def export_data(self):
        query = "SELECT * FROM ENCUESTA"
        records = self.db.fetch_all(query)
        columns = [desc[0] for desc in self.db.cursor.description]
        export_to_excel(records, columns)

    def show_charts(self):
        query = "SELECT Sexo, COUNT(*) as cantidad FROM ENCUESTA GROUP BY Sexo"
        records = self.db.fetch_all(query)
        if records:
            data = [(record['Sexo'], record['cantidad']) for record in records]
            plot_data(data, "Distribución por sexo")
        else:
            messagebox.showwarning("Sin datos", "No hay datos para mostrar en los gráficos.")

    def run(self):
        self.root.mainloop()
        self.db.close()


if __name__ == "__main__":
    app = App()
    app.run()
