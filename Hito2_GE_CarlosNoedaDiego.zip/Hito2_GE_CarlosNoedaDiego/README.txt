1.Dependencias:
De primeras tendremos que descargar las dependencias necesarias para el proyecto => pymysql, pandas y matplotlib.
Desde el propio Bush de pycharm debemos de añadir estas dependencias o sino descargarlo desde los propios setting 
pip install pymysql
pip install  pandas 
pip install  matplotlib
2.Base de datos
Para trabajar con el proyecto debemos de descargarnos MySQL workbench e insertar todo lo que hay en el docuemto BD.sql
y asegurarnos que en nuestro proyecto la clase Datosbase empiece asi:
class Database:
    def __init__(self, host="localhost", user="root", password="curso", database="ENCUESTAS"):
        ...
o editarlo según nuestro gusto

